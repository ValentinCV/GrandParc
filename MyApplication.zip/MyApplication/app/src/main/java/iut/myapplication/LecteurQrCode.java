package iut.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.List;

import me.dm7.barcodescanner.zxing.ZXingScannerView;


public class LecteurQrCode extends Activity implements ZXingScannerView.ResultHandler {
    private ZXingScannerView mScannerView;
    List<BarcodeFormat> barcodeFormats=new ArrayList<>();



    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        barcodeFormats.add(BarcodeFormat.QR_CODE);
        setContentView(R.layout.activity_lecteur_qr_code);
        mScannerView = (ZXingScannerView) findViewById(R.id.scan);   // Programmatically initialize the scanner view
        mScannerView.setFormats(barcodeFormats);
        mScannerView.setResultHandler(this); // Register ourselves as a handler for scan results.
        mScannerView.startCamera();  // Set the scanner view as the content view
    }

    @Override
    public void onResume() {
        super.onResume();
        mScannerView.startCamera();
    }

    @Override
    public void onPause() {
        super.onPause();
        mScannerView.stopCamera();
    }

    @Override
    public void handleResult(Result rawResult) {/*resulat du scan*/

        Toast.makeText(this,rawResult.getText(),Toast.LENGTH_LONG).show();
        Intent intentFicheProduit=new Intent(this,FicheProduit.class);
        intentFicheProduit.putExtra("idProduitExtra",rawResult.getText());
        startActivity(intentFicheProduit);
    }
}