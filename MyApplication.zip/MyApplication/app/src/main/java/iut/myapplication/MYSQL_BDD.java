package iut.myapplication;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;
import android.content.Context;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MYSQL_BDD extends AsyncTask{

    private String Host = null;
    private String DBB = null;
    private String User = null;
    private String Pass = null;
    String nom;
    private Connection Conn = null;

    MYSQL_BDD(String pHost, String pDBB, String pUser, String pPass)
    {
        Host = pHost;
        DBB= pDBB;
        User = pUser;
        Pass = pPass;
    }

    public String getNom()
    {
        return nom;
    }


    @Override
    protected Object doInBackground(Object... params) {
        // TODO Auto-generated method stub


        try
        {

            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Log.i("Driver", "Driver initialised");
            } catch (InstantiationException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                Log.e("Instanciation Driver", e.getMessage());
            } catch (IllegalAccessException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                Log.e("Access Exception", e.getMessage());
            } catch (ClassNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                Log.e("Class", e.getMessage());
            }


            String url = "jdbc:mysql://"+Host+"/"+DBB;
            String user = User;
            String passwd = Pass;

            Conn = DriverManager.getConnection(url, user, passwd);
            Log.i("Connection", "Etablished");


            ResultSet curseurJava;

            Statement etatSimple;
            String req="select * from News where id=6";
            try
            {
                etatSimple = Conn.createStatement();
                curseurJava=etatSimple.executeQuery(req);
                curseurJava.next();

                int id=curseurJava.getInt(1);
                nom = curseurJava.getString(2);

            }
            catch (SQLException e) {
                e.printStackTrace();
            }

        }
        catch(SQLException e)
        {
            e.printStackTrace();
            Log.e("MySQL", e.getMessage());
        };


        return Conn;
    };
}