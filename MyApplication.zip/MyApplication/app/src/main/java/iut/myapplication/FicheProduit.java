package iut.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Created by Valentin on 04/08/2015.
 */
public class FicheProduit extends Activity {

    private TextView nomProduit;
    private String idProduit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fiche_produit);
        nomProduit=(TextView) findViewById(R.id.textProduit);

        Bundle bundle = getIntent().getExtras();
        idProduit=bundle.getString("idProduitExtra");
        nomProduit.setText(idProduit);
    }



    @Override
    public void onPause()
    {
        System.out.println("Fermer pause fffffffffffffffffffffffffffffffffff");
        super.onPause();
        finish();
    }
}
