package iut.myapplication;

import java.io.PrintStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.Vector;

public abstract class BDD
{
  protected ResultSet curseurJava,curseurJava2,curseurJava3;
  protected Statement etatSimple,etat2,etatSimple3;
  protected String chaineConnexion;
  protected String login;
  protected String mdPasse;
  protected Connection conn;
  public Vector myAppli;
  private LinkedList<String> Pi;
  private int point=0;
  
  
  public BDD(String log, String mdp)
  {
    this.login = log;
    this.mdPasse = mdp;
  }
  
 /* public Pizza executerRequeteSelectPizza(int ligne)
  {
    String req = "select * from Pizza where num_pizza=" + ligne;
    LinkedList<Ingredient> ing=new LinkedList<Ingredient>();
    try
    {
      this.curseurJava = this.etatSimple.executeQuery(req);
      this.curseurJava.next();
      
      int id = this.curseurJava.getInt(1);
      System.out.println(this.curseurJava.getInt(1));
      String nom = this.curseurJava.getString(2);
      int point = this.curseurJava.getInt(3);
      float prix = this.curseurJava.getFloat(4);
      
      
      String req2 = "select * from ingredient where num_ingredient in (select num_ingredient from compo_pizz where num_pizza=" + id+");";
       this.curseurJava = this.etatSimple.executeQuery(req2);
     
      while(curseurJava.next())
      {
    	  ing.add(new Ingredient(curseurJava.getInt(1),curseurJava.getString(2)));
      }
      return new Pizza(id, nom, prix, point,ing);
    }
    catch (Exception ex)
    {
      System.err.println("Erreur 888: " + ex);
    }
    return null;
  }
  
  public Client executerRequeteSelectClient(int ligne)
  {
    String req = "select * from Client where num_client=" + ligne;
    try
    {
      this.curseurJava = this.etatSimple.executeQuery(req);
      this.curseurJava.next();
      
      int id = this.curseurJava.getInt(1);
      
      String nom = this.curseurJava.getString(2);
      String prenom = this.curseurJava.getString(3);
      String adresse = this.curseurJava.getString(4);
      String numTel = this.curseurJava.getString(5);
      int point = this.curseurJava.getInt(6);
      
      return new Client(id, point, numTel, nom, prenom, adresse);
    }
    catch (Exception ex)
    {
      System.err.println("Erreur 444: " + ex);
    }
    return null;
  }
  
  
  
  
  public Employe executerRequeteSelectEmploye(int ligne)
  {
    String req = "select * from Employe_CMDE where num_employe=" + ligne;
    try
    {
      this.curseurJava = this.etatSimple.executeQuery(req);
      this.curseurJava.next();
      
      int id = this.curseurJava.getInt(1);
      
      String nom = this.curseurJava.getString(2);
      String prenom = this.curseurJava.getString(3);
      float salaire = this.curseurJava.getFloat(4);
      
      
     
      
      return new Employe(id,salaire,nom,prenom);
    }
    catch (Exception ex)
    {
      System.err.println("Erreur 444: " + ex);
    }
    return null;
  }
  
  
  public Taille executerRequeteSelectTaille(int ligne)
  {
    String req = "select * from Taille where num_taille=" + ligne;
    try
    {
      this.curseurJava = this.etatSimple.executeQuery(req);
      this.curseurJava.next();
      
      int id = this.curseurJava.getInt(1);
      float coeff = this.curseurJava.getFloat(2);
      String nom = this.curseurJava.getString(3);
     
    
      
      
     
      
      return new Taille(id,coeff,nom);
    }
    catch (Exception ex)
    {
      System.err.println("Erreur 444: " + ex);
    }
    return null;
  }
  
  
  
  
  
  public int nbLigne(String nomTable)
  {
    String req = "select * from " + nomTable;
    try
    {
      this.curseurJava = this.etatSimple.executeQuery(req);
      int nbLigne = 0;
      while (this.curseurJava.next()) {
        nbLigne++;
      }
   
      return nbLigne;
    }
    catch (SQLException e)
    {
      e.printStackTrace();
    }
    return 0;
  }
  
  public void executerRequeteInsert(String req)
  {
    try
    {
      int result = this.etatSimple.executeUpdate(req);
      System.out.println();
      System.out.println("R?sultat de la requete : " + result);
      if (result == 0) {
        System.out.println("Cette requ?te a ?chou? ");
      } else {
        System.out.println("Cette requ?te a r?ussi ");
      }
    }
    catch (Exception ex)
    {
      System.err.println("Erreur : " + ex);
    }
  }
  
  
  public void updatePointClient(int points, Client client)
  {
	  
	  point=points;
	  
	  
	  String req="select pt_fidelite_client from Client where num_client="+client.getId()+";";
	  
	  try {
		this.curseurJava = this.etatSimple.executeQuery(req);
		curseurJava.next();
		
		int pointPrecedent=curseurJava.getInt(1);
		point=point+pointPrecedent;
		
		 String req2 = "update Client set pt_fidelite_client="+point+" where num_client="+client.getId()+";";
		 
		 this.etatSimple.executeUpdate(req2);
		 
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }
	  
	  public void retirerPointClient(int points, Client client)
	  {
		   
		  point=points;
		  
		  
		  String req="select pt_fidelite_client from Client where num_client="+client.getId()+";";
		  
		  try {
			this.curseurJava = this.etatSimple.executeQuery(req);
			curseurJava.next();
			
			int pointPrecedent=curseurJava.getInt(1);
			point=pointPrecedent-point;
			
			 String req2 = "update Client set pt_fidelite_client="+point+" where num_client="+client.getId()+";";
			 
			 this.etatSimple.executeUpdate(req2);
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 
	  
	  
	  
	  
	  
	  
	  
	  
	  
  }
  
	  public float getTemp() {
		  String req = "SELECT SUM( qte_pizza ) , ((SUM( qte_pizza ) - ( SUM( qte_pizza ) %6 )) /6) *15 AS temps_au_plus_court FROM compo_cmde JOIN commande USING ( num_cmde ) WHERE fini =0";
		  try {
		this.curseurJava = this.etatSimple.executeQuery(req);
		this.curseurJava.next();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
			try {
				return this.curseurJava.getFloat(2);
			} catch (SQLException e) {
				e.printStackTrace();
				return 0;
			}
		}
	  
	  public int[] getHeure(){
		  int[] date=new int[3];
		  String req = "SELECT hour(Sysdate()),minute(Sysdate()),second(Sysdate()) from dual ";
		  try {
		this.curseurJava = this.etatSimple.executeQuery(req);
		this.curseurJava.next();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		  
		try {
			date[0]=curseurJava.getInt(1);
			date[1]=curseurJava.getInt(2);
			date[2]=curseurJava.getInt(3);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		  return date;
	  }
  
  
  
  */
  
  
  
}
