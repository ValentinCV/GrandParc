package iut.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.ExecutionException;

/**
 * Created by Valentin on 04/08/2015.
 */
public class ListeNews extends Activity {

    private ListView liste;
    private String[] contenue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_news);
        liste=(ListView)findViewById(R.id.listViewNews);
        contenue= new String[] {"Test 1","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2","test2"};
        MYSQL_BDD classConn = new MYSQL_BDD("88.175.12.41", "BaseGrandParc", "testAndroid", "cvbn");
        classConn.execute((Integer)null);


        while(classConn.getNom()==null)
        {

        }

        contenue[0]=classConn.getNom();


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                R.layout.ligne_liste_news, R.id.textItem, contenue);
        //Changer image : http://www.vogella.com/tutorials/AndroidListView/article.html


        liste.setAdapter(adapter);
        liste.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView <?> parent, View view,
                                    int position, long id) {

                // ListView Clicked item index
                int itemPosition     = position;

                // ListView Clicked item value
                String  itemValue    = (String) liste.getItemAtPosition(position);

                // Show Alert
                Toast.makeText(getApplicationContext(),
                        "Position :"+itemPosition+"  ListItem : " +itemValue , Toast.LENGTH_LONG)
                        .show();

            }

        });

        /*BDD*/










    }




}


