package iut.myapplication;

import android.content.Context;
import android.content.Intent;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

/**
 * Created by Valentin on 04/08/2015.
 */
public class BarreNavigation extends LinearLayout {

    private Context context;

    public BarreNavigation(Context context, AttributeSet attrs) {
        super(context, attrs);
        View.inflate(context, R.layout.view_barre_menu, this);
        this.context=context;
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

        ((Button)findViewById(R.id.button_bn_Acceuil)).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intentLecteur=new Intent(context,MainActivity.class);
                context.startActivity(intentLecteur);



            }
        });
        /*...*/

    }
}
